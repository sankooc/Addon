local mod	= DBM:NewMod(477, "DBM-Party-Classic", 19, 240)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20200215182107")
mod:SetCreatureID(3653)
mod:SetEncounterID(587)

mod:RegisterCombat("combat")
