local mod	= DBM:NewMod("Oggleflint", "DBM-Party-Classic", 9)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20200215182107")
mod:SetCreatureID(11517)
--mod:SetEncounterID(1443)

mod:RegisterCombat("combat")
