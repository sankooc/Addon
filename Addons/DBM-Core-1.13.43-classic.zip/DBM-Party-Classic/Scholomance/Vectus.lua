local mod	= DBM:NewMod("Vectus", "DBM-Party-Classic", 13)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20200215182107")
mod:SetCreatureID(10432)

mod:RegisterCombat("combat")
