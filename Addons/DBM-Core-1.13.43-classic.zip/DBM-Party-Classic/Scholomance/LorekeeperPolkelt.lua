local mod	= DBM:NewMod("LorekeeperPolkelt", "DBM-Party-Classic", 13)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20200215182107")
mod:SetCreatureID(10901)

mod:RegisterCombat("combat")
