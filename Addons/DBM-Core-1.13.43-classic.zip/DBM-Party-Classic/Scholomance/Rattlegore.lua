local mod	= DBM:NewMod("Rattlegore", "DBM-Party-Classic", 13)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20200215182107")
mod:SetCreatureID(11622)

mod:RegisterCombat("combat")
