local mod	= DBM:NewMod("GoralukAnvilcrack", "DBM-Party-Classic", 4)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20200215182107")
mod:SetCreatureID(10899)

mod:RegisterCombat("combat")
