local mod	= DBM:NewMod("Rethilgore", "DBM-Party-Classic", 14)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20200215182107")
mod:SetCreatureID(3914)

mod:RegisterCombat("combat")
